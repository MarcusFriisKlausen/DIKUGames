namespace TestDIKUArcade;

public interface ITestable {

    void RunTest();
    void Help();
}
