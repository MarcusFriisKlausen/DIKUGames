namespace DIKUArcade.Input {
    public enum KeyboardLayout {
        Danish,
        English_US
    }
}
