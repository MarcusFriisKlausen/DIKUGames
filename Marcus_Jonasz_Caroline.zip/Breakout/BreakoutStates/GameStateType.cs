public enum GameStateType {
    GameRunning,
    GamePaused,
    MainMenu,
    GameLost
}